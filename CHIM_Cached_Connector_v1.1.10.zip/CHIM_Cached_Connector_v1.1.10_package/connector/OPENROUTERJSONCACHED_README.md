# OpenRouter JSON Cached Connector v1.1.10

**Version**: 1.1.10
**Date**: 2025/11/13
**Compatible with**: CHIM 2.0.3

## Overview

The OpenRouter JSON Cached connector is an advanced connector that provides:
- **Prompt caching** support for Anthropic, OpenAI, and Gemini providers
- **Response format control** - JSON or simple text formats
- **Reasoning model support** - Handles models like DeepSeek-R1, o1, o3, etc.
- **Streaming optimization** - Efficient real-time response processing

## What's New in v1.1.10

### Critical Bug Fixes
✅ **Fixed flush not called on finish_reason** - CRITICAL BUG
  - Previous versions only flushed at EOF or [DONE] markers
  - When max_tokens reached (finish_reason: 'length'), flush wasn't triggered
  - Trailing content was lost when stream ended with finish_reason
  - Now flush is called at ALL stream end conditions:
    - Anthropic `stop_reason` detection (line 930-938)
    - OpenAI `finish_reason` detection (line 973-982)
    - `message_stop` event (line 1002-1011)

### Improvements
✅ **Added diagnostic logging for minimize_quality_prompt**
  - Logs current model name
  - Logs whether minimize_quality_prompt setting was found
  - Logs which prompt template is being used (minimized vs full)
  - Helps diagnose when setting doesn't work as expected
  - Logging in prompts/dialogue_prompt.php lines 32-56

### Previous Fixes (from v1.1.9)
✅ **Leading colon preservation** - Reverted incorrect colon stripping
✅ **Enhanced flush logging** - Added detailed diagnostic logging

### Previous Fixes (from v1.1.8)
✅ **New simple format parser** - Fixes "Halfan" bug, duplication, lost sentences
✅ **Reasoning token preprocessing** - Handles `<think>`, `<thinking>`, `<answer>` tags
✅ **Trailing partial flush** - Fixes data loss at stream end
✅ **Timeout fallback** - Graceful degradation at 100 chars

## Files Included

### Core Connector (4 files)
- `openrouterjsoncached.php` - Main cached connector (v1.1.10)
- `openrouterjsoncached_verbose.php` - Verbose debugging version
- `openrouterjsoncached_helpers.php` - Helper functions
- `__jpd.php` - JSON parsing dependency

### Dependencies (3 files)
- `lib/tokenizer_helper_functions.php` - Token stripping utilities
- `lib/core/llm_connector.class.php` - Base connector class
- `functions/json_response.php` - Response formatting

### Configuration (1 file)
- `conf/conf_schema.json` - Configuration schema with caching options

### UI Files (5 files)
- `ui/core/core_profiles.php` - Profile management
- `ui/core/llm_connectors.php` - Connector configuration UI
- `ui/conf_wizard.php` - Configuration wizard
- `ui/conf_wizardbackup.php` - Backup configuration wizard
- `ui/quickstart.php` - Quick start guide

## Installation

1. **Backup your current files** (especially if you have custom modifications)

2. **Copy connector files**:
   ```
   connector/openrouterjsoncached*.php → [CHIM]/connector/
   connector/__jpd.php → [CHIM]/connector/
   ```

3. **Copy dependencies**:
   ```
   lib/tokenizer_helper_functions.php → [CHIM]/lib/
   lib/core/llm_connector.class.php → [CHIM]/lib/core/
   functions/json_response.php → [CHIM]/functions/
   ```

4. **Copy configuration**:
   ```
   conf/conf_schema.json → [CHIM]/conf/
   ```

5. **Copy UI files** (optional but recommended):
   ```
   ui/core/* → [CHIM]/ui/core/
   ui/conf_wizard*.php → [CHIM]/ui/
   ui/quickstart.php → [CHIM]/ui/
   ```

6. **Copy prompts** (if updating minimize_quality_prompt diagnostic logging):
   ```
   prompts/dialogue_prompt.php → [CHIM]/prompts/
   ```

7. **Clear cache** (important when upgrading):
   ```
   Delete [CHIM]/temp/system_cache_*.tmp
   Delete [CHIM]/temp/combined_dialogue_cache_*.tmp
   ```

8. **Verify installation**:
   - Check logs: `log/cache.log` for initialization message showing v1.1.10
   - Test with simple format enabled
   - Monitor `log/cache.log` for flush diagnostic messages
   - Check `log/lastlog.log` for dialogue_prompt diagnostic messages

## Diagnostic Logging

### Flush Diagnostics (in log/cache.log)
v1.1.10 includes comprehensive flush logging:

```
[openrouterjsoncached] Flush: Message length=XXX, first 100 chars: ...
[openrouterjsoncached] Flush: Found X complete sentences, already sent Y
[openrouterjsoncached] Flush: Last punctuation at position Z, partial length=...
[openrouterjsoncached] Flushing trailing partial (XXX chars): "..."
```

These logs appear when stream ends (EOF, [DONE], finish_reason, stop_reason, message_stop).

### Minimize Quality Prompt Diagnostics (in log/lastlog.log)
v1.1.10 includes logging for prompt template selection:

```
[dialogue_prompt] Current model: openrouterjsoncached
[dialogue_prompt] minimize_quality_prompt setting found: true
[dialogue_prompt] Using MINIMIZED prompt template
```

Or if setting not found:
```
[dialogue_prompt] minimize_quality_prompt setting NOT found, using default: true
[dialogue_prompt] Using FULL/LEGACY prompt template
```

## Configuration

### Response Format Options

**JSON Format** (default):
```json
{
  "mood": "happy",
  "listener": "Player",
  "action": "Talk",
  "target": "Lydia",
  "message": "Hello there!"
}
```

**Simple Format**:
```
(mood)(listener)(action)(target): message content here.
Example: (happy)(Player)(Talk)(Lydia): Hello there!
```

Set in configuration:
```
response_format = "simple"  // or "json"
```

### Field Control

Enable/disable specific fields:
```
include_mood_requirement = true/false
include_listener_requirement = true/false
include_actions_list = true/false
include_target_requirement = true/false
```

### Cache Settings

```
provider_caching = "Anthropic"  // or "OpenAI", "Gemini"
max_dialogue_cache_context_size = 200  // tokens
dialogue_cache_uncached_count = 4  // messages to keep fresh
```

### Minimize Quality Prompt

```
minimize_quality_prompt = true  // Recommended for advanced models (Claude 3.5+, GPT-4+)
minimize_quality_prompt = false  // Use for older/smaller models
```

## Troubleshooting

### Simple Format Issues

**Problem**: LLM not following format
**Solution**: Check timeout fallback in logs (triggers at 100 chars)

**Problem**: Leading colons being stripped
**Status**: Fixed in v1.1.9 - colons are now preserved

**Problem**: Missing action descriptions at end of response
**Status**: Should be fixed in v1.1.10 - flush now called on finish_reason
**Diagnosis**: Check `log/cache.log` for flush messages showing:
- Whether partial was detected
- Partial content and length
- Why it was/wasn't returned

**Problem**: Content cut off when max_tokens reached
**Status**: Fixed in v1.1.10 - flush now triggers on finish_reason: 'length'

### Prompt Template Issues

**Problem**: minimize_quality_prompt setting doesn't work
**Diagnosis**: Check `log/lastlog.log` for diagnostic messages showing:
- Current model name
- Whether setting was found in configuration
- Which template is being used
- If setting not found, verify configuration path and format

### Reasoning Models

Models with reasoning support:
- DeepSeek-R1, QwQ-32B (explicit `<think>` tags)
- OpenAI o1/o3/o4, GPT-5 (internal reasoning)
- Qwen3-thinking variants

The connector automatically:
- Strips reasoning tokens from output
- Handles prefill cases (orphaned closing tags)
- Preserves format detection integrity

### Cache Efficiency

Check `_cached_perf.log` for cache statistics:
- **Read tokens**: Served from cache (fast, cheap)
- **Create tokens**: Building new cache
- **New tokens**: Fresh uncached content
- **Efficiency**: Read/(Read+Create+New) percentage

Target 70%+ efficiency after warmup.

## Version History

- **v1.1.10** (2025/11/13) - Fixed flush on finish_reason, added minimize_quality_prompt logging
- **v1.1.9** (2025/11/13) - Fixed colon preservation, added flush logging
- **v1.1.8** (2025/11/13) - New simple format parser, flush logic
- **v1.0.24** (2025/11/12) - Bug fixes for streaming
- **v1.0.19f** (2025/11/11) - Format investigation, UI improvements

## Support

- **Documentation**: See INSTALLATION_INSTRUCTIONS.txt
- **Changelog**: See CHANGELOG.txt for complete version history
- **Design Document**: See CODING-DESIGN-DOCUMENT-FOR-CLAUDE.md (on GitHub)

## License

Same license as CHIM framework.
