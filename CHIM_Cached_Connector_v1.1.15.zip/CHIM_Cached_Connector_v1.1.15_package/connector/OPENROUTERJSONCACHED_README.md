# OpenRouter JSON Cached Connector v1.1.12

**Version**: 1.1.12
**Date**: 2025/11/13
**Compatible with**: CHIM 2.0.3

## Overview

The OpenRouter JSON Cached connector is an advanced connector that provides:
- **Prompt caching** support for Anthropic, OpenAI, and Gemini providers
- **Response format control** - JSON or simple text formats
- **Reasoning model support** - Handles models like DeepSeek-R1, o1, o3, etc.
- **Streaming optimization** - Efficient real-time response processing
- **minimize_quality_prompt** - Now fully functional!

## What's New in v1.1.12

### Feature Implementation
✅ **Fully implemented minimize_quality_prompt setting**
  - v1.1.10/v1.1.11 attempted to add diagnostic logging but caused bugs
  - Feature existed in UI and schema but had no backend implementation
  - Now properly checks connector setting and applies minimized template
  - When enabled: Uses `" Write {NPC}'s next dialogue line."`
  - When disabled: Uses full template with quality instructions
  - Recommended for advanced models (Claude 3.5+, GPT-4+, Gemini 2.0)
  - Located in prompts/dialogue_prompt.php lines 28-37

### Previous Fixes (from v1.1.10)
✅ **Fixed flush on finish_reason** - Trailing content no longer lost when max_tokens reached
✅ **Added flush at all stream end conditions** - Anthropic stop_reason, OpenAI finish_reason, message_stop

### Previous Fixes (from v1.1.9)
✅ **Leading colon preservation** - Reverted incorrect colon stripping
✅ **Enhanced flush logging** - Detailed diagnostic logging

### Previous Fixes (from v1.1.8)
✅ **New simple format parser** - Fixes "Halfan" bug, duplication, lost sentences
✅ **Reasoning token preprocessing** - Handles `<think>`, `<thinking>`, `<answer>` tags
✅ **Trailing partial flush** - Fixes data loss at stream end
✅ **Timeout fallback** - Graceful degradation at 100 chars

## Files Included

### Core Connector (4 files)
- `openrouterjsoncached.php` - Main cached connector (v1.1.12)
- `openrouterjsoncached_verbose.php` - Verbose debugging version
- `openrouterjsoncached_helpers.php` - Helper functions
- `__jpd.php` - JSON parsing dependency

### Dependencies (3 files)
- `lib/tokenizer_helper_functions.php` - Token stripping utilities
- `lib/core/llm_connector.class.php` - Base connector class
- `functions/json_response.php` - Response formatting

### Configuration (1 file)
- `conf/conf_schema.json` - Configuration schema with caching options

### Prompts (1 file) ✨ UPDATED IN v1.1.12
- `prompts/dialogue_prompt.php` - Dialogue prompt with working minimize_quality_prompt

### UI Files (5 files)
- `ui/core/core_profiles.php` - Profile management
- `ui/core/llm_connectors.php` - Connector configuration UI
- `ui/conf_wizard.php` - Configuration wizard
- `ui/conf_wizardbackup.php` - Backup configuration wizard
- `ui/quickstart.php` - Quick start guide

## Installation

1. **Backup your current files** (especially if you have custom modifications)

2. **Copy connector files**:
   ```
   connector/openrouterjsoncached*.php → [CHIM]/connector/
   connector/__jpd.php → [CHIM]/connector/
   ```

3. **Copy dependencies**:
   ```
   lib/tokenizer_helper_functions.php → [CHIM]/lib/
   lib/core/llm_connector.class.php → [CHIM]/lib/core/
   functions/json_response.php → [CHIM]/functions/
   ```

4. **Copy configuration**:
   ```
   conf/conf_schema.json → [CHIM]/conf/
   ```

5. **Copy prompts** ⚠️ REQUIRED for minimize_quality_prompt:
   ```
   prompts/dialogue_prompt.php → [CHIM]/prompts/
   ```

6. **Copy UI files** (optional but recommended):
   ```
   ui/core/* → [CHIM]/ui/core/
   ui/conf_wizard*.php → [CHIM]/ui/
   ui/quickstart.php → [CHIM]/ui/
   ```

7. **Clear cache** (important when upgrading):
   ```
   Delete [CHIM]/temp/system_cache_*.tmp
   Delete [CHIM]/temp/combined_dialogue_cache_*.tmp
   ```

8. **Verify installation**:
   - Check logs: `log/cache.log` for initialization message showing v1.1.12
   - Test minimize_quality_prompt toggle in connector settings
   - Monitor `log/cache.log` for flush diagnostic messages

## Configuration

### minimize_quality_prompt (NOW WORKING!)

**Location**: Connector settings UI → "Minimize Quality Instructions"

**Behavior**:
- **Enabled (default)**: `" Write {NPC}'s next dialogue line."`
  - Recommended for: Claude 3.5+, GPT-4+, Gemini 2.0
  - Advanced models inherently understand creativity and quality

- **Disabled**: Full template with explicit quality instructions
  - Recommended for: Llama 70B, older Mistral, smaller models
  - Provides explicit guidance: "be creative, avoid repetition"

**Configuration**:
```
minimize_quality_prompt = true   // Minimized (recommended for advanced models)
minimize_quality_prompt = false  // Full template (for older/smaller models)
```

### Response Format Options

**JSON Format** (default):
```json
{
  "mood": "happy",
  "listener": "Player",
  "action": "Talk",
  "target": "Lydia",
  "message": "Hello there!"
}
```

**Simple Format**:
```
(mood)(listener)(action)(target): message content here.
Example: (happy)(Player)(Talk)(Lydia): Hello there!
```

Set in configuration:
```
response_format = "simple"  // or "json"
```

### Field Control

Enable/disable specific fields:
```
include_mood_requirement = true/false
include_listener_requirement = true/false
include_actions_list = true/false
include_target_requirement = true/false
```

### Cache Settings

```
provider_caching = "Anthropic"  // or "OpenAI", "Gemini"
max_dialogue_cache_context_size = 200  // tokens
dialogue_cache_uncached_count = 4  // messages to keep fresh
```

## Troubleshooting

### minimize_quality_prompt Issues

**Problem**: Setting doesn't seem to apply
**Solution**:
- Ensure you copied prompts/dialogue_prompt.php from v1.1.12
- Clear cache after upgrading
- Check that DMgetCurrentModel() function is available
- Verify setting is saved in connector configuration

**Problem**: Not sure which template is being used
**Solution**:
- Check the prompts being sent to LLM in logs
- Full template contains: "should be a casual direct reaction..."
- Minimized template is just: "Write {NPC}'s next dialogue line."

### Simple Format Issues

**Problem**: LLM not following format
**Solution**: Check timeout fallback in logs (triggers at 100 chars)

**Problem**: Leading colons being stripped
**Status**: Fixed in v1.1.9 - colons are now preserved

**Problem**: Missing action descriptions at end of response
**Status**: Fixed in v1.1.10 - flush now called on finish_reason
**Diagnosis**: Check `log/cache.log` for flush messages

**Problem**: Content cut off when max_tokens reached
**Status**: Fixed in v1.1.10 - flush triggers on finish_reason: 'length'

### Reasoning Models

Models with reasoning support:
- DeepSeek-R1, QwQ-32B (explicit `<think>` tags)
- OpenAI o1/o3/o4, GPT-5 (internal reasoning)
- Qwen3-thinking variants

The connector automatically:
- Strips reasoning tokens from output
- Handles prefill cases (orphaned closing tags)
- Preserves format detection integrity

### Cache Efficiency

Check `_cached_perf.log` for cache statistics:
- **Read tokens**: Served from cache (fast, cheap)
- **Create tokens**: Building new cache
- **New tokens**: Fresh uncached content
- **Efficiency**: Read/(Read+Create+New) percentage

Target 70%+ efficiency after warmup.

## Version History

- **v1.1.12** (2025/11/13) - Implemented minimize_quality_prompt functionality
- **v1.1.11** (2025/11/13) - Removed buggy diagnostic logging (SKIP THIS VERSION)
- **v1.1.10** (2025/11/13) - Flush on finish_reason + diagnostic logging (BROKEN)
- **v1.1.9** (2025/11/13) - Fixed colon preservation, added flush logging
- **v1.1.8** (2025/11/13) - New simple format parser, flush logic
- **v1.0.24** (2025/11/12) - Bug fixes for streaming
- **v1.0.19f** (2025/11/11) - Format investigation, UI improvements

## Support

- **Documentation**: See INSTALLATION_INSTRUCTIONS.txt
- **Changelog**: See CHANGELOG.txt for complete version history
- **Design Document**: See CODING-DESIGN-DOCUMENT-FOR-CLAUDE.md (on GitHub)

## License

Same license as CHIM framework.
