# OpenRouter JSON Cached Connector v1.1.9

**Version**: 1.1.9
**Date**: 2025/11/13
**Compatible with**: CHIM 2.0.3

## Overview

The OpenRouter JSON Cached connector is an advanced connector that provides:
- **Prompt caching** support for Anthropic, OpenAI, and Gemini providers
- **Response format control** - JSON or simple text formats
- **Reasoning model support** - Handles models like DeepSeek-R1, o1, o3, etc.
- **Streaming optimization** - Efficient real-time response processing

## What's New in v1.1.9

### Bug Fixes
✅ **Leading colon preservation** - Reverted incorrect colon stripping
  - Previous v1.1.8 incorrectly stripped leading `:` from messages
  - Now preserves colons as intended: `:` stays as `:`

✅ **Enhanced flush logging** - Added detailed diagnostic logging
  - Logs message length and preview during flush
  - Logs complete sentence count vs already sent
  - Logs partial detection details (position, length)
  - Logs why partial is/isn't returned
  - Helps diagnose missing action descriptions

### Previous Fixes (from v1.1.8)
✅ **New simple format parser** - Fixes "Halfan" bug, duplication, lost sentences
✅ **Reasoning token preprocessing** - Handles `<think>`, `<thinking>`, `<answer>` tags
✅ **Trailing partial flush** - Fixes data loss at stream end
✅ **Timeout fallback** - Graceful degradation at 100 chars

## Files Included

### Core Connector (4 files)
- `openrouterjsoncached.php` - Main cached connector (v1.1.9)
- `openrouterjsoncached_verbose.php` - Verbose debugging version
- `openrouterjsoncached_helpers.php` - Helper functions
- `__jpd.php` - JSON parsing dependency

### Dependencies (3 files)
- `lib/tokenizer_helper_functions.php` - Token stripping utilities
- `lib/core/llm_connector.class.php` - Base connector class
- `functions/json_response.php` - Response formatting

### Configuration (1 file)
- `conf/conf_schema.json` - Configuration schema with caching options

### UI Files (5 files)
- `ui/core/core_profiles.php` - Profile management
- `ui/core/llm_connectors.php` - Connector configuration UI
- `ui/conf_wizard.php` - Configuration wizard
- `ui/conf_wizardbackup.php` - Backup configuration wizard
- `ui/quickstart.php` - Quick start guide

## Installation

1. **Backup your current files** (especially if you have custom modifications)

2. **Copy connector files**:
   ```
   connector/openrouterjsoncached*.php → [CHIM]/connector/
   connector/__jpd.php → [CHIM]/connector/
   ```

3. **Copy dependencies**:
   ```
   lib/tokenizer_helper_functions.php → [CHIM]/lib/
   lib/core/llm_connector.class.php → [CHIM]/lib/core/
   functions/json_response.php → [CHIM]/functions/
   ```

4. **Copy configuration**:
   ```
   conf/conf_schema.json → [CHIM]/conf/
   ```

5. **Copy UI files** (optional but recommended):
   ```
   ui/core/* → [CHIM]/ui/core/
   ui/conf_wizard*.php → [CHIM]/ui/
   ui/quickstart.php → [CHIM]/ui/
   ```

6. **Clear cache** (if upgrading from v1.0.x):
   ```
   Delete [CHIM]/temp/system_cache_*.tmp
   Delete [CHIM]/temp/combined_dialogue_cache_*.tmp
   ```

7. **Verify installation**:
   - Check logs: `log/cache.log` for initialization message showing v1.1.9
   - Test with simple format enabled
   - Monitor `log/cache.log` for flush diagnostic messages

## Diagnostic Logging

v1.1.9 includes comprehensive flush logging to help diagnose issues:

```
[openrouterjsoncached] Flush: Message length=XXX, first 100 chars: ...
[openrouterjsoncached] Flush: Found X complete sentences, already sent Y
[openrouterjsoncached] Flush: Last punctuation at position Z, partial length=...
[openrouterjsoncached] Flushing trailing partial (XXX chars): "..."
```

These logs appear in `log/cache.log` when stream ends, showing exactly what's being flushed.

## Configuration

### Response Format Options

**JSON Format** (default):
```json
{
  "mood": "happy",
  "listener": "Player",
  "action": "Talk",
  "target": "Lydia",
  "message": "Hello there!"
}
```

**Simple Format**:
```
(mood)(listener)(action)(target): message content here.
Example: (happy)(Player)(Talk)(Lydia): Hello there!
```

Set in configuration:
```
response_format = "simple"  // or "json"
```

### Field Control

Enable/disable specific fields:
```
include_mood_requirement = true/false
include_listener_requirement = true/false
include_actions_list = true/false
include_target_requirement = true/false
```

### Cache Settings

```
provider_caching = "Anthropic"  // or "OpenAI", "Gemini"
max_dialogue_cache_context_size = 200  // tokens
dialogue_cache_uncached_count = 4  // messages to keep fresh
```

## Troubleshooting

### Simple Format Issues

**Problem**: LLM not following format
**Solution**: Check timeout fallback in logs (triggers at 100 chars)

**Problem**: Leading colons being stripped
**Status**: Fixed in v1.1.9 - colons are now preserved

**Problem**: Missing action descriptions at end of response
**Diagnosis**: Check `log/cache.log` for flush messages showing:
- Whether partial was detected
- Partial content and length
- Why it was/wasn't returned

### Reasoning Models

Models with reasoning support:
- DeepSeek-R1, QwQ-32B (explicit `<think>` tags)
- OpenAI o1/o3/o4, GPT-5 (internal reasoning)
- Qwen3-thinking variants

The connector automatically:
- Strips reasoning tokens from output
- Handles prefill cases (orphaned closing tags)
- Preserves format detection integrity

### Cache Efficiency

Check `_cached_perf.log` for cache statistics:
- **Read tokens**: Served from cache (fast, cheap)
- **Create tokens**: Building new cache
- **New tokens**: Fresh uncached content
- **Efficiency**: Read/(Read+Create+New) percentage

Target 70%+ efficiency after warmup.

## Version History

- **v1.1.9** (2025/11/13) - Fixed colon preservation, added flush logging
- **v1.1.8** (2025/11/13) - New simple format parser, flush logic
- **v1.0.24** (2025/11/12) - Bug fixes for streaming
- **v1.0.19f** (2025/11/11) - Format investigation, UI improvements

## Support

- **Documentation**: See INSTALLATION_INSTRUCTIONS.txt
- **Changelog**: See CHANGELOG.txt for complete version history
- **Design Document**: See CODING-DESIGN-DOCUMENT-FOR-CLAUDE.md (on GitHub)

## License

Same license as CHIM framework.
