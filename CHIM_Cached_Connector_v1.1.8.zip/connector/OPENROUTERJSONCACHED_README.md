# OpenRouter JSON Cached Connector v1.1.8

**Version**: 1.1.8
**Date**: 2025/11/13
**Compatible with**: CHIM 2.0.3

## Overview

The OpenRouter JSON Cached connector is an advanced connector that provides:
- **Prompt caching** support for Anthropic, OpenAI, and Gemini providers
- **Response format control** - JSON or simple text formats
- **Reasoning model support** - Handles models like DeepSeek-R1, o1, o3, etc.
- **Streaming optimization** - Efficient real-time response processing

## What's New in v1.1.8

### Critical Bug Fixes
✅ **New simple format parser** - Completely rewritten to fix:
  - "Halfan" bug (word concatenation from offset desync)
  - Message duplication from length tracking errors
  - Lost sentences from position calculation failures

✅ **Reasoning token preprocessing** - Handles `<think>`, `<thinking>`, `<answer>` tags:
  - State machine for reliable tag stripping
  - Supports prefill cases (orphaned closing tags)
  - Prevents format detection interference

✅ **Trailing partial flush** - Fixes data loss at stream end:
  - Flushes unsent complete sentences
  - Adds period to trailing partials
  - Returns content incrementally across process() calls

### Architecture Improvements
- **Single buffer approach** - No separate sentence buffer
- **Wait when ambiguous** - Only processes complete patterns
- **No offset math** - Index-based sentence tracking prevents bugs
- **Timeout fallback** - Graceful degradation at 100 chars when LLM ignores format

## Files Included

### Core Connector (4 files)
- `openrouterjsoncached.php` - Main cached connector
- `openrouterjsoncached_verbose.php` - Verbose debugging version
- `openrouterjsoncached_helpers.php` - Helper functions
- `__jpd.php` - JSON parsing dependency

### Dependencies (3 files)
- `lib/tokenizer_helper_functions.php` - Token stripping utilities
- `lib/core/llm_connector.class.php` - Base connector class
- `functions/json_response.php` - Response formatting

### Configuration (1 file)
- `conf/conf_schema.json` - Configuration schema with caching options

### UI Files (5 files)
- `ui/core/core_profiles.php` - Profile management
- `ui/core/llm_connectors.php` - Connector configuration UI
- `ui/conf_wizard.php` - Configuration wizard
- `ui/conf_wizardbackup.php` - Backup configuration wizard
- `ui/quickstart.php` - Quick start guide

## Installation

1. **Backup your current files** (especially if you have custom modifications)

2. **Copy connector files**:
   ```
   connector/openrouterjsoncached*.php → [CHIM]/connector/
   connector/__jpd.php → [CHIM]/connector/
   ```

3. **Copy dependencies**:
   ```
   lib/tokenizer_helper_functions.php → [CHIM]/lib/
   lib/core/llm_connector.class.php → [CHIM]/lib/core/
   functions/json_response.php → [CHIM]/functions/
   ```

4. **Copy configuration**:
   ```
   conf/conf_schema.json → [CHIM]/conf/
   ```

5. **Copy UI files** (optional but recommended):
   ```
   ui/core/* → [CHIM]/ui/core/
   ui/conf_wizard*.php → [CHIM]/ui/
   ui/quickstart.php → [CHIM]/ui/
   ```

6. **Clear cache** (if upgrading from v1.0.x):
   ```
   Delete [CHIM]/temp/system_cache_*.tmp
   Delete [CHIM]/temp/combined_dialogue_cache_*.tmp
   ```

7. **Verify installation**:
   - Check logs: `log/cache.log` for initialization message
   - Test with simple format enabled
   - Monitor `log/debugStream.log` for parsing behavior

## Configuration

### Response Format Options

**JSON Format** (default):
```json
{
  "mood": "happy",
  "listener": "Player",
  "action": "Talk",
  "target": "Lydia",
  "message": "Hello there!"
}
```

**Simple Format**:
```
(mood)(listener)(action)(target): message content here.
Example: (happy)(Player)(Talk)(Lydia): Hello there!
```

Set in configuration:
```
response_format = "simple"  // or "json"
```

### Field Control

Enable/disable specific fields:
```
include_mood_requirement = true/false
include_listener_requirement = true/false
include_actions_list = true/false
include_target_requirement = true/false
```

### Cache Settings

```
provider_caching = "Anthropic"  // or "OpenAI", "Gemini"
max_dialogue_cache_context_size = 200  // tokens
dialogue_cache_uncached_count = 4  // messages to keep fresh
```

## Troubleshooting

### Simple Format Issues

**Problem**: LLM not following format
**Solution**: Check timeout fallback in logs (triggers at 100 chars)

**Problem**: Word concatenation ("Halfan" bug)
**Status**: Fixed in v1.1.8 - no longer possible due to new parser

**Problem**: Duplicate text
**Status**: Fixed in v1.1.8 - simple counter prevents duplication

**Problem**: Lost trailing text
**Status**: Fixed in v1.1.8 - flush mechanism handles all cases

### Reasoning Models

Models with reasoning support:
- DeepSeek-R1, QwQ-32B (explicit `<think>` tags)
- OpenAI o1/o3/o4, GPT-5 (internal reasoning)
- Qwen3-thinking variants

The connector automatically:
- Strips reasoning tokens from output
- Handles prefill cases (orphaned closing tags)
- Preserves format detection integrity

### Cache Efficiency

Check `_cached_perf.log` for cache statistics:
- **Read tokens**: Served from cache (fast, cheap)
- **Create tokens**: Building new cache
- **New tokens**: Fresh uncached content
- **Efficiency**: Read/(Read+Create+New) percentage

Target 70%+ efficiency after warmup.

## Technical Details

### Parser Architecture

**Old approach** (v1.0.x):
- Separate sentence buffer
- Multiple offset variables
- Complex position calculations
- **Result**: Prone to desync bugs

**New approach** (v1.1.8):
- Single buffer
- Index-based sentence tracking
- Combined metadata+sentence detection
- **Result**: Mathematically impossible to desync

### Reasoning Preprocessing

Runs as Step 0 (before all parsing):
1. Check for orphaned closing tag (prefill case)
2. State machine: NORMAL ↔ WAITING_FOR_REASONING_CLOSE
3. Strip `<answer>` tags (preserve content)
4. Only then proceed to format parsing

### Flush Logic

At stream end (EOF or [DONE]):
1. Return unsent complete sentences (priority 1)
2. Find trailing partial after last punctuation
3. Add period if needed
4. Return partial (priority 2)

## Support

- **Documentation**: See INSTALLATION_INSTRUCTIONS.txt
- **Changelog**: See CHANGELOG.txt for complete version history
- **Design Document**: See CODING-DESIGN-DOCUMENT-FOR-CLAUDE.md

## License

Same license as CHIM framework.
